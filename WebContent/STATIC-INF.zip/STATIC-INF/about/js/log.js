/*$(function(){
	$("#submit").click(function(){
		
		$.ajax({
			type:"POST",
			url:"http://115.28.158.106:8080/market/User/login",
            contentType:"application/json;charset=utf-8",
            data:JSON.stringify({"account":$("#username").val(),
			                     "password":$("#password").val()}),
            dataType:"json",
            success:function(data){
            	alert(data);
            },
            error:function(data){
            	alert("ERROR" + data);
            }
		});
	})
});*/
$(function(){
    $("#goback").hover(function(){
      $(this).removeClass("button_default").addClass("button_hover");
    },function(){
      $(this).removeClass("button_hover").addClass("button_default");
    });
});